#!/bin/bash


echo Hello
exit 19
echo Bye

## 1. exit command stop the script if it is encountered, No more commands will get executed
## 2. simple exit command returns 0 as the exit status.

