#!/bin/bash

read -p 'Enter your Name: ' name
read -p 'Enter your age: ' age


echo -e "\n Your Name = $name\n Your Age = $age"
