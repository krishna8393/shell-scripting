#!/bin/bash

#! is called as she-bang,
# 1. It is used to denote the path of interpreter (Interpreter is the one which executes the given order), & exexutes all the commands in the file/script using that interpreter
# 2. It has to be in the line number 1.
# 3. Adding more she-bangs in next lines will not have any impact.

# All the above lines starting with # are the comments,
# 1. Comments are used for adding some description for the code , like why you added that , for future reference.
# 2. Commented lines are ignored by the interpreters.

ls
find /etc -name passwd

